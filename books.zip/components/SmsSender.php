<?php

namespace app\components;

use Yii;

class SmsSender
{
    private string $apiKey;
    private string $sender;
    private string $apiUrl = 'http://smspilot.ru/api.php';

    /**
     * Конструктор
     * @param string $apiKey API-ключ SMSPILOT
     * @param string $sender Имя отправителя (из списка в личном кабинете)
     */
    public function __construct(string $apiKey = '', string $sender = 'INFORM')
    {
        $this->apiKey = $apiKey ?: 'XXXXXXXXXXXXYYYYYYYYYYYYZZZZZZZZXXXXXXXXXXXXYYYYYYYYYYYYZZZZZZZZ';
        $this->sender = $sender;
    }

    /**
     * Отправка SMS
     * @param string $phone номер телефона в международном формате (например 79037672215)
     * @param string $text текст сообщения
     * @return array|false Возвращает массив ответа или false при ошибке
     */
    public function send(string $phone, string $text)
    {
        $url = $this->apiUrl . '?' . http_build_query([
            'send' => $text,
            'to' => $phone,
            'from' => $this->sender,
            'apikey' => $this->apiKey,
            'format' => 'json'
        ]);

        $json = @file_get_contents($url);
        if ($json === false) {
            Yii::error("SMS sending failed for $phone: file_get_contents returned false");
            return false;
        }

        $response = json_decode($json, true);

        if (!isset($response['send'][0]['server_id'])) {
            Yii::error("SMS sending failed for $phone: invalid response " . $json);
            return false;
        }

        Yii::info("SMS sent to $phone, id=" . $response['send'][0]['server_id']);
        return $response;
    }
}
