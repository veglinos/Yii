<?php
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $books app\models\Book[] */

$this->title = 'Список книг';
?>

<h1><?= Html::encode($this->title) ?></h1>

<p>
    <?= Html::a('Добавить новую книгу', ['create'], ['class' => 'btn btn-success']) ?>
</p>

<?php foreach (Yii::$app->session->getAllFlashes() as $type => $message): ?>
    <div class="alert alert-<?= $type ?>"><?= $message ?></div>
<?php endforeach; ?>

<table border="1" cellpadding="5" cellspacing="0">
    <tr>
        <th>Название</th>
        <th>Год</th>
        <th>ISBN</th>
        <th>Описание</th>
        <th>Действия</th>
    </tr>
    <?php foreach ($books as $book): ?>
        <tr>
            <td><?= Html::encode($book->title) ?></td>
            <td><?= Html::encode($book->publish_year) ?></td>
            <td><?= Html::encode($book->isbn) ?></td>
            <td><?= Html::encode($book->description) ?></td>
            <td>
                <?= Html::a('Редактировать', ['update', 'id' => $book->id], ['class' => 'btn btn-primary']) ?>
                <?= Html::a('Удалить', ['delete', 'id' => $book->id], [
                    'class' => 'btn btn-danger',
                    'data' => [
                        'confirm' => 'Вы уверены, что хотите удалить эту книгу?',
                        'method' => 'post',
                    ],
                ]) ?>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
