<?php
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $topAuthors array */
/* @var $year int */

$this->title = "ТОП 10 авторов за $year год";
?>

<h1><?= Html::encode($this->title) ?></h1>

<table border="1" cellpadding="5" cellspacing="0">
    <tr>
        <th>Автор</th>
        <th>Количество книг</th>
    </tr>
    <?php if (empty($topAuthors)): ?>
        <tr><td colspan="2">Данные за <?= Html::encode($year) ?> год отсутствуют.</td></tr>
    <?php else: ?>
        <?php foreach ($topAuthors as $author): ?>
            <tr>
                <td><?= Html::encode($author['full_name']) ?></td>
                <td><?= Html::encode($author['books_count']) ?></td>
            </tr>
        <?php endforeach; ?>
    <?php endif; ?>
</table>