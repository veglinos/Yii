<?php
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $books app\models\Book[] */

$this->title = 'Список книг';
?>

<h1><?= Html::encode($this->title) ?></h1>

<?php foreach (Yii::$app->session->getAllFlashes() as $type => $message): ?>
    <div class="alert alert-<?= $type ?>"><?= $message ?></div>
<?php endforeach; ?>

<?php if (!Yii::$app->user->isGuest): ?>
    <p>
        <?= Html::a('Добавить книгу', ['create'], ['class' => 'btn btn-success']) ?>
    </p>
<?php endif; ?>

<table border="1" cellpadding="5" cellspacing="0">
    <tr>
        <th>ID</th>
        <th>Название</th>
        <th>Год</th>
        <th>ISBN</th>
        <th>Авторы</th>
        <th>Описание</th>
        <?php if (!Yii::$app->user->isGuest): ?>
            <th>Действия</th>
        <?php endif; ?>
    </tr>
    <?php foreach ($books as $book): ?>
        <tr>
            <td><?= Html::encode($book->id) ?></td>
            <td><?= Html::encode($book->title) ?></td>
            <td><?= Html::encode($book->publish_year) ?></td>
            <td><?= Html::encode($book->isbn) ?></td>
            <td>
                <?= implode(', ', array_map(fn($a) =>
                    Html::a(Html::encode($a->full_name), ['author/view', 'id' => $a->id]),
                    $book->authors
                )) ?>
            </td>
            <td><?= Html::encode($book->description) ?></td>
            <?php if (!Yii::$app->user->isGuest): ?>
                <td>
                    <?= Html::a('Редактировать', ['update', 'id' => $book->id], ['class' => 'btn btn-primary']) ?>
                    <?= Html::a('Удалить', ['delete', 'id' => $book->id], [
                        'class' => 'btn btn-danger',
                        'data' => [
                            'confirm' => 'Удалить эту книгу?',
                            'method' => 'post',
                        ],
                    ]) ?>
                </td>
            <?php endif; ?>
        </tr>
    <?php endforeach; ?>
</table>
