<?php
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $authors app\models\Author[] */

$this->title = 'Список авторов';
?>

<h1><?= Html::encode($this->title) ?></h1>

<?php foreach (Yii::$app->session->getAllFlashes() as $type => $message): ?>
    <div class="alert alert-<?= $type ?>"><?= $message ?></div>
<?php endforeach; ?>

<?php if (!Yii::$app->user->isGuest): ?>
    <p>
        <?= Html::a('Добавить автора', ['create'], ['class' => 'btn btn-success']) ?>
    </p>
<?php endif; ?>

<table border="1" cellpadding="5" cellspacing="0">
    <tr>
        <th>ID</th>
        <th>ФИО</th>
        <?php if (!Yii::$app->user->isGuest): ?>
            <th>Действия</th>
        <?php endif; ?>
    </tr>
    <?php foreach ($authors as $author): ?>
        <tr>
            <td><?= Html::encode($author->id) ?></td>
            <td><?= Html::encode($author->full_name) ?></td>
            <?php if (!Yii::$app->user->isGuest): ?>
                <td>
                    <?= Html::a('Редактировать', ['update', 'id' => $author->id], ['class' => 'btn btn-primary']) ?>
                    <?= Html::a('Удалить', ['delete', 'id' => $author->id], [
                        'class' => 'btn btn-danger',
                        'data' => [
                            'confirm' => 'Вы уверены, что хотите удалить этого автора?',
                            'method' => 'post',
                        ],
                    ]) ?>
                </td>
            <?php endif; ?>
        </tr>
    <?php endforeach; ?>
</table>

