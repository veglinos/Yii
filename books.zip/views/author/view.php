<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $model app\models\Author */
/* @var $subscription app\models\BookSubscription */

$this->title = $model->full_name;
?>

<h1><?= Html::encode($this->title) ?></h1>

<h3>Книги автора:</h3>
<ul>
<?php foreach ($model->books as $book): ?>
    <li><?= Html::encode($book->title) ?></li>
<?php endforeach; ?>
</ul>

<hr>
<?php if (Yii::$app->user->isGuest): ?>
<h3>Подписка на автора</h3>

<?php $form = ActiveForm::begin(); ?>

<?= $form->field($subscription, 'phone')->textInput(['placeholder' => '+7...']) ?>

<div class="form-group">
    <?= Html::submitButton('Подписаться', ['class' => 'btn btn-primary']) ?>
</div>

<?php ActiveForm::end(); ?>
<?php endif; ?>