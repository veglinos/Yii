<?php

namespace app\controllers;

use Yii;
use app\models\Book;
use app\models\Author;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\AccessControl;
use yii\filters\VerbFilter;
use app\components\SmsSender;
use app\models\BookSubscription;

class BookController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'only' => ['create', 'update', 'delete'],
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::class,
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    public function actionIndex()
    {
        $books = Book::find()->with('authors')->all();
        return $this->render('index', ['books' => $books]);
    }

    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    public function actionCreate()
    {
        $model = new Book();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {

            // Отправляем SMS подписчикам авторов книги
            $this->notifySubscribers($model);

            Yii::$app->session->setFlash('success', 'Книга успешно добавлена.');
            return $this->redirect(['index']);
        }

        $authors = Author::find()->all();
        return $this->render('create', ['model' => $model, 'authors' => $authors]);
    }

    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {

            // Отправляем SMS подписчикам авторов книги
            $this->notifySubscribers($model);

            Yii::$app->session->setFlash('success', 'Книга успешно обновлена.');
            return $this->redirect(['index']);
        }

        $authors = Author::find()->all();
        return $this->render('update', ['model' => $model, 'authors' => $authors]);
    }

    public function actionDelete($id)
    {
        $this->findModel($id)->delete();
        Yii::$app->session->setFlash('success', 'Книга удалена.');
        return $this->redirect(['index']);
    }

    protected function findModel($id)
    {
        if (($model = Book::findOne($id)) !== null) {
            return $model;
        }
        throw new NotFoundHttpException('Книга не найдена.');
    }

   protected function notifySubscribers($book)
    {
        $sms = new SmsSender('XXXXXXXXXXXXYYYYYYYYYYYYZZZZZZZZXXXXXXXXXXXXYYYYYYYYYYYYZZZZZZZZ', 'INFORM');

        // Получаем всех подписчиков-гостей авторов книги
        $authorIds = $book->getAuthors()->select('id')->column();

        $subscriptions = \app\models\BookSubscription::find()
            ->where(['author_id' => $authorIds])
            ->andWhere(['not', ['phone' => null]]) // только телефоны гостей
            ->all();

        foreach ($subscriptions as $sub) {
            $phone = $sub->phone;
            $message = "Новая книга автора доступна: {$book->title}";
            $sms->send($phone, $message);
        }
    }


}
