<?php

namespace app\controllers;

use Yii;
use app\models\Author;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\AccessControl;
use yii\filters\VerbFilter;
use app\models\User;

class AuthorController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'only' => ['create', 'update', 'delete'],
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'], // только авторизованные
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::class,
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    // Список авторов
    public function actionIndex()
    {
        $authors = Author::find()->all();
        return $this->render('index', ['authors' => $authors]);
    }

    public function actionCreate()
    {
        $model = new Author();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            Yii::$app->session->setFlash('success', 'Автор успешно добавлен.');
            return $this->redirect(['index']);
        }

        return $this->render('create', ['model' => $model]);
    }

    // Редактирование
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            Yii::$app->session->setFlash('success', 'Автор успешно обновлён.');
            return $this->redirect(['index']);
        }

        return $this->render('update', ['model' => $model]);
    }

    // Удаление
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();
        Yii::$app->session->setFlash('success', 'Автор удалён.');
        return $this->redirect(['index']);
    }

    protected function findModel($id)
    {
        if (($model = Author::findOne($id)) !== null) {
            return $model;
        }
        throw new NotFoundHttpException('Автор не найден.');
    }

   public function actionView($id)
{
    $author = $this->findModel($id);
    $subscription = new \app\models\BookSubscription();

    if (Yii::$app->request->isPost && $subscription->load(Yii::$app->request->post())) {
        // 1. Создаём нового пользователя
        $user = new \app\models\User();
        // Генерируем уникальное имя
        do {
            $username = 'user' . rand(1000, 9999);
        } while (\app\models\User::find()->where(['username' => $username])->exists());

        $user->username = $username;
        $user->email = 'mail@mail.ru';
        $plainPassword = Yii::$app->security->generateRandomString(8);
        $user->password_hash = Yii::$app->security->generatePasswordHash($plainPassword);
        $user->auth_key = Yii::$app->security->generateRandomString();
        $user->role = 'guest';

        if ($user->save()) {
            // 2. Создаём подписку
            $subscription->user_id = $user->id;
            $subscription->author_id = $author->id;
            $subscription->created_at = date('Y-m-d H:i:s');

            if ($subscription->save()) {
                Yii::$app->session->setFlash('success', 'Вы успешно подписались на автора.');
                return $this->refresh();
            } else {
                Yii::$app->session->setFlash('error', 'Ошибка при сохранении подписки.');
            }
        } else {
            Yii::$app->session->setFlash('error', 'Ошибка при создании пользователя.');
        }
    }

    return $this->render('view', [
        'model' => $author,
        'subscription' => $subscription,
    ]);
}


}
