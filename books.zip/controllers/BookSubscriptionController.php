<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use yii\web\Response;
use app\models\BookSubscription;
use yii\web\BadRequestHttpException;

class BookSubscriptionController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class' => \yii\filters\AccessControl::class,
                'only' => ['subscribe', 'unsubscribe'],
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'], // только авторизованные пользователи
                    ],
                ],
            ],
        ];
    }

    // Подписка
    public function actionSubscribe()
    {
        Yii::$app->response->format = Response::FORMAT_JSON;

        $authorId = Yii::$app->request->post('author_id');

        if (!$authorId) {
            throw new BadRequestHttpException('Недостаточно данных.');
        }

        $userId = Yii::$app->user->id;

        // Проверка, есть ли уже подписка
        $existing = BookSubscription::findOne([
            'user_id' => $userId,
            'author_id' => $authorId,
        ]);

        if ($existing) {
            return ['status' => 'error', 'message' => 'Вы уже подписаны на этого автора.'];
        }

        $subscription = new BookSubscription([
            'user_id' => $userId,
            'author_id' => $authorId,
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        if ($subscription->save()) {
            return ['status' => 'success', 'message' => 'Подписка оформлена.'];
        }

        return ['status' => 'error', 'message' => 'Ошибка при сохранении подписки.'];
    }

    public function actionUnsubscribe()
    {
        Yii::$app->response->format = Response::FORMAT_JSON;

        $authorId = Yii::$app->request->post('author_id');

        if (!$authorId) {
            throw new BadRequestHttpException('Недостаточно данных.');
        }

        $userId = Yii::$app->user->id;

        $subscription = BookSubscription::findOne([
            'user_id' => $userId,
            'author_id' => $authorId,
        ]);

        if (!$subscription) {
            return ['status' => 'error', 'message' => 'Подписка не найдена.'];
        }

        if ($subscription->delete()) {
            return ['status' => 'success', 'message' => 'Вы отписались от автора.'];
        }

        return ['status' => 'error', 'message' => 'Ошибка при удалении подписки.'];
    }
}