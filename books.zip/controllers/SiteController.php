<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\ContactForm;
use app\models\Book;

class SiteController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::class,
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
            'access' => [
            'class' => AccessControl::class,
            'only' => ['manage-books'],
            'rules' => [
                [
                    'allow' => true,
                    'roles' => ['@'], // только для авторизованных
                ],
            ],
        ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    /**
     * Displays homepage.
     *
     * @return string
     */
    public function actionIndex()
    {
        return $this->render('index');
    }

    /**
     * Login action.
     *
     * @return Response|string
     */
    public function actionLogin()
    {
        if (!Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->goBack();
        }

        $model->password = '';
        return $this->render('login', [
            'model' => $model,
        ]);
    }

    /**
     * Logout action.
     *
     * @return Response
     */
    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->goHome();
    }

    /**
     * Displays contact page.
     *
     * @return Response|string
     */
    public function actionContact()
    {
        $model = new ContactForm();
        if ($model->load(Yii::$app->request->post()) && $model->contact(Yii::$app->params['adminEmail'])) {
            Yii::$app->session->setFlash('contactFormSubmitted');

            return $this->refresh();
        }
        return $this->render('contact', [
            'model' => $model,
        ]);
    }

    /**
     * Displays about page.
     *
     * @return string
     */
    public function actionAbout()
    {
        return $this->render('about');
    }

public function actionBooks()
{
    $books = Book::find()->all(); // получаем все книги
    return $this->render('books', [
        'books' => $books,
    ]);
}

public function actionTopAuthors($year)
{
    $query = (new \yii\db\Query())
        ->select(['a.full_name', 'COUNT(ba.book_id) AS books_count'])
        ->from(['a' => 'authors'])
        ->innerJoin(['ba' => 'book_author'], 'ba.author_id = a.id')
        ->innerJoin(['b' => 'books'], 'b.id = ba.book_id')
        ->where(['b.publish_year' => $year])
        ->groupBy('a.id')
        ->orderBy(['books_count' => SORT_DESC])
        ->limit(10);

    $topAuthors = $query->all();

    return $this->render('top-authors', [
        'topAuthors' => $topAuthors,
        'year' => $year,
    ]);
}



public function actionManageBooks()
{
    $books = \app\models\Book::find()->all();
    return $this->render('manage-books', ['books' => $books]);
}

}

