<?php
use yii\db\Migration;

class m260606_000006_seed_books extends Migration
{
    public function safeUp()
    {
               // Вставка книг
        $this->batchInsert('{{%books}}', ['title', 'created_by'], [
            ['Война и мир', 1],
            ['Преступление и наказание', 1],
            ['Евгений Онегин', 1],
            ['Вишнёвый сад', 1],
            ['Мёртвые души', 1],
            ['Отверженные', 1],
            ['20000 лье под водой', 1],
            ['Гордость и предубеждение', 1],
            ['Оливер Твист', 1],
            ['Приключения Тома Сойера', 1],
        ]);

    }

    public function safeDown()
    {
        $this->delete('{{%book_authors}}', ['book_id' => range(1,10)]);
        $this->delete('{{%books}}', ['id' => range(1,10)]);
        $this->delete('{{%authors}}', ['id' => range(1,10)]);
    }
}