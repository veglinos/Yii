<?php

use yii\db\Migration;

class m260101_000001_insert_admin_user extends Migration
{
    public function safeUp()
    {
        $password = '123456';
        $passwordHash = \Yii::$app->security->generatePasswordHash($password);

        $this->insert('{{%user}}', [
            'username' => 'admin',
            'password_hash' => $passwordHash,
            'role' => 'user',                   
            'email' => 'admin@example.com',       
            'auth_key' => \Yii::$app->security->generateRandomString(),
        ]);
    }

    public function safeDown()
    {
        $this->delete('{{%user}}', ['username' => 'admin']);
    }
}