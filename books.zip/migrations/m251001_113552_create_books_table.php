<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%books}}`.
 */
class m251001_113552_create_books_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%books}}', [
            'id' => $this->primaryKey(),
            'title' => $this->string()->notNull(),
            'publish_year' => $this->integer(4),
            'description' => $this->text(),
            'isbn' => $this->string(20),
            'photo_path' => $this->string(),
            'created_by' => $this->integer(),
        ]);
        
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
         $this->dropForeignKey('fk-books-created_by', '{{%books}}');
        $this->dropTable('{{%books}}');
    }
}
