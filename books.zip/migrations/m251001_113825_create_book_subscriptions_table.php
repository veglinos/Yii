<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%book_subscriptions}}`.
 */
class m251001_113825_create_book_subscriptions_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%book_subscriptions}}', [
            'id' => $this->primaryKey(),
            'user_id' => $this->integer()->notNull(),
            'phone' => $this->string(50),
            'author_id' => $this->integer()->notNull(),
            'created_at' => $this->integer()->notNull(),
        ]);

        // Внешний ключ для user_id на таблицу user
        $this->addForeignKey(
            'fk-book_subscriptions-user_id',
            '{{%book_subscriptions}}',          
            'user_id',                         
            '{{%user}}',                      
            'id',                              
            'CASCADE'
        );

      
        $this->addForeignKey(
            'fk-book_subscriptions-author_id',
            '{{%book_subscriptions}}',         
            'author_id',                        
            '{{%authors}}',                     
            'id',                             
            'CASCADE'
        );

        
        $this->createIndex(
            'idx-unique-user_author',
            '{{%book_subscriptions}}',
            ['user_id', 'author_id'],
            true
        );
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropIndex('idx-unique-user_author', '{{%book_subscriptions}}');
        $this->dropForeignKey('fk-book_subscriptions-author_id', '{{%book_subscriptions}}');
        $this->dropForeignKey('fk-book_subscriptions-user_id', '{{%book_subscriptions}}');
        $this->dropTable('{{%book_subscriptions}}');
    }
}