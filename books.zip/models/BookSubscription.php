<?php

namespace app\models;

use yii\db\ActiveRecord;

class BookSubscription extends ActiveRecord
{
    public static function tableName()
    {
        return 'book_subscriptions';
    }

    public function rules()
    {
        return [
            [['user_id', 'phone', 'author_id'], 'required'],
            [['user_id', 'author_id'], 'integer'],
            [['phone'], 'string', 'max' => 20],
        ];
    }

    public function attributeLabels()
    {
        return [
            'phone' => 'Телефон',
        ];
    }

    public function getAuthor()
    {
        return $this->hasOne(Author::class, ['id' => 'author_id']);
    }
}
