<?php

namespace app\models;

use yii\db\ActiveRecord;

class Book extends ActiveRecord
{
    public $authorIds = []; // для формы выбора авторов

    public static function tableName()
    {
        return 'books';
    }

    public function rules()
    {
        return [
            [['title', 'publish_year'], 'required'],
            [['publish_year', 'created_by'], 'integer'],
            [['description'], 'string'],
            [['title', 'isbn', 'photo_path'], 'string', 'max' => 255],
            [['authorIds'], 'each', 'rule' => ['integer']],
        ];
    }

    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'title' => 'Название',
            'publish_year' => 'Год издания',
            'description' => 'Описание',
            'isbn' => 'ISBN',
            'photo_path' => 'Путь к фото',
            'created_by' => 'Создал',
            'authorIds' => 'Авторы',
        ];
    }

    // Связь с авторами через таблицу book_author
    public function getAuthors()
    {
        return $this->hasMany(Author::class, ['id' => 'author_id'])
            ->viaTable('book_author', ['book_id' => 'id']);
    }

    // После сохранения — обновляем связи с авторами
    public function afterSave($insert, $changedAttributes)
    {
        parent::afterSave($insert, $changedAttributes);

        \Yii::$app->db->createCommand()
            ->delete('book_author', ['book_id' => $this->id])
            ->execute();

        if (is_array($this->authorIds)) {
            foreach ($this->authorIds as $authorId) {
                \Yii::$app->db->createCommand()
                    ->insert('book_author', [
                        'book_id' => $this->id,
                        'author_id' => $authorId,
                        ])->execute();
            }
        }
    }

    // Загружаем выбранных авторов в форму
    public function afterFind()
    {
        parent::afterFind();
        $this->authorIds = $this->getAuthors()->select('id')->column();
    }
}
